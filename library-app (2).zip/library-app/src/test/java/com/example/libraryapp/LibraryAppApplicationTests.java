package com.example.libraryapp;

import com.example.libraryapp.entity.Author;
import com.example.libraryapp.entity.Book;
import com.example.libraryapp.repository.BookRepository;
import com.example.libraryapp.service.LibraryService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@SpringBootTest
class LibraryAppApplicationTests {

    @Mock
    private BookRepository bookRepository;

    @InjectMocks
    private LibraryService libraryService;

    @Test
    void testGetAllBooks() {
        // Arrange
        Author author = new Author("Test Author");
        Book book1 = new Book("Book 1", "Sci-Fi", author);
        Book book2 = new Book("Book 2", "Fantasy", author);
        when(bookRepository.findAll()).thenReturn(Arrays.asList(book1, book2));

        // Act
        List<Book> books = libraryService.getAllBooks();

        // Assert
        assertEquals(2, books.size());
        verify(bookRepository, times(1)).findAll();
    }

    @Test
    void testSearchBooksByAuthorName() {
        // Arrange
        Author author = new Author("Orwell");
        Book book1 = new Book("1984", "Dystopian", author);
        when(bookRepository.findBooksByAuthorName("Orwell")).thenReturn(List.of(book1));

        // Act
        List<Book> result = libraryService.searchBooksByAuthor("Orwell");

        // Assert
        assertEquals(1, result.size());
        assertEquals("1984", result.get(0).getTitle());
    }
}