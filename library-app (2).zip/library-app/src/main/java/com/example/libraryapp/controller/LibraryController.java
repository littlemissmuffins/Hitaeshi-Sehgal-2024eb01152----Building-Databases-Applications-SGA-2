package com.example.libraryapp.controller;

import com.example.libraryapp.entity.Book;
import com.example.libraryapp.service.LibraryService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/")
public class LibraryController {

    private final LibraryService libraryService;

    public LibraryController(LibraryService libraryService) {
        this.libraryService = libraryService;
    }

    // READ: Display all books
    @GetMapping
    public String viewHomePage(Model model) {
        model.addAttribute("listBooks", libraryService.getAllBooks());
        return "index";
    }

    // CREATE: Show Add Form
    @GetMapping("/showNewBookForm")
    public String showNewBookForm(Model model) {
        Book book = new Book();
        model.addAttribute("book", book);
        model.addAttribute("authors", libraryService.getAllAuthors());
        return "new_book";
    }

    // CREATE / UPDATE: Save Book
    @PostMapping("/saveBook")
    public String saveBook(@ModelAttribute("book") Book book) {
        libraryService.saveBook(book);
        return "redirect:/";
    }

    // UPDATE: Show Edit Form
    @GetMapping("/showFormForUpdate/{id}")
    public String showFormForUpdate(@PathVariable(value = "id") Long id, Model model) {
        Book book = libraryService.getBookById(id);
        model.addAttribute("book", book);
        model.addAttribute("authors", libraryService.getAllAuthors());
        return "update_book";
    }

    // CUSTOM QUERY: Search by Author
    @GetMapping("/search")
    public String searchByAuthor(@RequestParam("authorName") String authorName, Model model) {
        model.addAttribute("listBooks", libraryService.searchBooksByAuthor(authorName));
        model.addAttribute("searchQuery", authorName);
        return "index";
    }
}