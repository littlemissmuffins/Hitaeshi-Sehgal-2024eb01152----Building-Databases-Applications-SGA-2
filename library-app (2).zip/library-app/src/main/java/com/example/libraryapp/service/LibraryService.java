package com.example.libraryapp.service;

import com.example.libraryapp.entity.Author;
import com.example.libraryapp.entity.Book;
import com.example.libraryapp.repository.AuthorRepository;
import com.example.libraryapp.repository.BookRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class LibraryService {

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;

    public LibraryService(BookRepository bookRepository, AuthorRepository authorRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
    }

    public List<Book> getAllBooks() { return bookRepository.findAll(); }
    public List<Author> getAllAuthors() { return authorRepository.findAll(); }

    public Book getBookById(Long id) {
        return bookRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid book Id:" + id));
    }

    public void saveBook(Book book) { bookRepository.save(book); }

    public void deleteBook(Long id) { bookRepository.deleteById(id); }

    public List<Book> searchBooksByAuthor(String authorName) {
        return bookRepository.findBooksByAuthorName(authorName);
    }
}