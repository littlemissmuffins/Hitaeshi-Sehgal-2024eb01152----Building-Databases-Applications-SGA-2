package com.example.libraryapp;

import com.example.libraryapp.entity.Author;
import com.example.libraryapp.entity.Book;
import com.example.libraryapp.repository.AuthorRepository;
import com.example.libraryapp.repository.BookRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements CommandLineRunner {

    private final AuthorRepository authorRepository;
    private final BookRepository bookRepository;

    public DataLoader(AuthorRepository authorRepository, BookRepository bookRepository) {
        this.authorRepository = authorRepository;
        this.bookRepository = bookRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        if(authorRepository.count() == 0) {
            Author author1 = authorRepository.save(new Author("George Orwell"));
            Author author2 = authorRepository.save(new Author("J.K. Rowling"));
            Author author3 = authorRepository.save(new Author("J.R.R. Tolkien"));

            bookRepository.save(new Book("1984", "Dystopian", author1));
            bookRepository.save(new Book("Animal Farm", "Political Satire", author1));
            bookRepository.save(new Book("Harry Potter and the Sorcerer's Stone", "Fantasy", author2));
            bookRepository.save(new Book("Harry Potter and the Chamber of Secrets", "Fantasy", author2));
            bookRepository.save(new Book("Harry Potter and the Prisoner of Azkaban", "Fantasy", author2));
            bookRepository.save(new Book("The Hobbit", "High Fantasy", author3));
            bookRepository.save(new Book("The Fellowship of the Ring", "High Fantasy", author3));
            bookRepository.save(new Book("The Two Towers", "High Fantasy", author3));
            bookRepository.save(new Book("The Return of the King", "High Fantasy", author3));
            bookRepository.save(new Book("The Silmarillion", "Mythopoeia", author3));
        }
    }
}