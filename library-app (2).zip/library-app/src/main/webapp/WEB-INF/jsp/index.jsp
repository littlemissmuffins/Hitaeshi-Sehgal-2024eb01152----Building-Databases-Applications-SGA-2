<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
<head>
    <title>Library Management</title>
    <!-- Bootstrap 5 CSS for a professional look -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="text-primary">Library Management System</h1>
        <a href="/showNewBookForm" class="btn btn-success btn-lg">+ Add New Book</a>
    </div>

    <!-- Search Bar using your Custom Inner Join Query -->
    <form action="/search" method="get" class="mb-4 d-flex">
        <input type="text" name="authorName" class="form-control me-2" placeholder="Search by Author Name..." value="${searchQuery}">
        <button type="submit" class="btn btn-outline-primary">Search</button>
        <a href="/" class="btn btn-outline-secondary ms-2">Reset</a>
    </form>

    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                <tr>
                    <th>Book ID</th>
                    <th>Title</th>
                    <th>Genre</th>
                    <th>Author</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <!-- Loop through the books passed from the controller -->
                <c:forEach var="book" items="${listBooks}">
                    <tr>
                        <td>${book.id}</td>
                        <td class="fw-bold">${book.title}</td>
                        <td><span class="badge bg-info text-dark">${book.genre}</span></td>
                        <td>${book.author.name}</td>
                        <td>
                            <a href="/showFormForUpdate/${book.id}" class="btn btn-warning btn-sm">Update</a>
                        </td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>