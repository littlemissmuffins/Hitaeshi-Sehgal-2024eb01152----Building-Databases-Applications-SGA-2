<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<html>
<head>
    <title>Update Book</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header bg-warning text-dark">
                    <h3 class="mb-0">Update Book Details</h3>
                </div>
                <div class="card-body">
                    <form:form action="/saveBook" modelAttribute="book" method="POST">
                        <!-- Hidden ID is crucial so Spring knows we are updating an existing row, not creating a new one -->
                        <form:hidden path="id" />

                        <div class="mb-3">
                            <label class="form-label fw-bold">Book Title</label>
                            <form:input path="title" class="form-control" required="true" />
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Genre</label>
                            <form:input path="genre" class="form-control" required="true" />
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-bold">Select Author</label>
                            <form:select path="author.id" class="form-select">
                                <form:options items="${authors}" itemValue="id" itemLabel="name"/>
                            </form:select>
                        </div>
                        <button type="submit" class="btn btn-warning w-100 fw-bold">Update Book</button>
                        <a href="/" class="btn btn-outline-secondary w-100 mt-2">Cancel</a>
                    </form:form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>